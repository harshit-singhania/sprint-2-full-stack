-- =============================================================
-- data-derby.sql - Auto-generated DB snapshot
-- Generated: 2026-06-10 02:02:42
-- Executed automatically on app startup.
-- Inserts are idempotent (WHERE NOT EXISTS guards).
-- =============================================================

SELECT 1 FROM SYSIBM.SYSDUMMY1;

-- USERS : (empty)

-- CARS : (empty)

-- PAYMENTS : (empty)

-- PURCHASE_ORDERS : (empty)

-- RECENT_VIEWS : (empty)

-- WISHLIST_ITEMS : (empty)

-- FEEDBACK : (empty)

-- SUPPORT_TICKETS : (empty)

-- TICKET_RESPONSES : (empty)

